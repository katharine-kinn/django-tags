=====
Tags
=====

django-tags-app is a simple app to add tags to your existing models.

Quick start
-----------

1. Add "tags_app" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = (
        ...
        'tags_app',
    )
